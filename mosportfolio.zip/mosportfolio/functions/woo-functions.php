<?php
if ( ! function_exists( 'is_shop' ) ) :
	function is_shop() {
		return false;
	}
endif;
if ( ! function_exists( 'is_product_category' ) ) :
	function is_product_category() {
		return false;
	}
endif;