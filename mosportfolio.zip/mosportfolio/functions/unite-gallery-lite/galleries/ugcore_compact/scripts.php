<?php


defined('_JEXEC') or die('Restricted access');

	HelperGalleryUG::addScript("js/compact_admin.js", "compact_admin");
?>