<?php


defined('_JEXEC') or die('Restricted access');

	HelperGalleryUG::addScript("js/grid_admin.js", "grid_admin");
?>