<?php
	$settings = new UniteGallerySettingsUG();
	$settings->loadXMLFile(GlobalsUG::$pathHelpersSettings."position.xml");
?>