<?php


defined('_JEXEC') or die('Restricted access');

require_once GlobalsUG::$pathHelpersClasses."settings_ug.class.php";
require_once GlobalsUG::$pathHelpersClasses."output_ug.class.php";
?>