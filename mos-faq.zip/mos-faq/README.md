# Mos FAQ
Mos FAQ plugin that lets you easily create, order and publicize FAQs using shortcodes.
