<?php
/*
Plugin Name: Mos FAQ
Plugin URI: http://mostak.belocal.today/plugins/mos-faq/
Description: Mos FAQ plugin that lets you easily create, order and publicize FAQs using shortcodes.
Version: 1.2
Author: Md. Mostak Shahid
Author URI: http://mostak.belocal.today/
License: GPL2
*/

require_once ( plugin_dir_path( __FILE__ ) . 'mos-faq-array.php' );
require_once ( plugin_dir_path( __FILE__ ) . 'mos-faq-functions.php' );
require_once ( plugin_dir_path( __FILE__ ) . 'mos-faq-settings.php' );
require_once ( plugin_dir_path( __FILE__ ) . 'mos-faq-post-types.php' );
require_once ( plugin_dir_path( __FILE__ ) . 'mos-faq-taxonomy.php' );